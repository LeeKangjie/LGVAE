import numpy as np
import scipy.sparse as sp
import scipy.io as sio
import torch
from torch.nn.functional import normalize


device = ""
if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")


def load_data(dataset_str,path="./data/"): 
    path = path + dataset_str +"/"

    if dataset_str == "spacing":
        features = sio.loadmat(path + "feature")
        features = features['matrix']
        layouts = sio.loadmat(path + "layout")
        layouts = layouts['matrix']
        features = torch.FloatTensor(np.array(features.todense()))
        layouts = torch.FloatTensor(np.array(layouts.todense()))

    elif dataset_str == "spacing+adjacency":
        features = sio.loadmat(path + "feature")
        features = features['matrix']
        layouts = sio.loadmat(path + "layout")
        layouts = layouts['matrix']

        features = torch.FloatTensor(np.array(features.todense()))
        layouts = torch.FloatTensor(np.array(layouts.todense()))
        

    else:
        features = sio.loadmat(path + "feature")
        features = features['matrix']
        layouts = sio.loadmat(path + "layout")
        layouts = layouts['matrix']

        features = torch.FloatTensor(np.array(features.todense()))
        layouts = torch.FloatTensor(np.array(layouts.todense()))
        

    return features, layouts

    