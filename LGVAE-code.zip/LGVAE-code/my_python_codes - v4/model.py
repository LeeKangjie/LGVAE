import torch
from torch import nn
import torch.nn.functional as F

device = ""
if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")


features = 16
mask=torch.ones(100).to(device)
mask[30]=0.0
mask[31]=0.0
mask[32]=0.0
mask[33]=0.0
mask[40]=0.0
mask[41]=0.0
mask[42]=0.0
mask[43]=0.0
mask[50]=0.0
mask[51]=0.0
mask[52]=0.0
mask[53]=0.0
mask[60]=0.0
mask[61]=0.0
mask[62]=0.0
mask[63]=0.0

# define a simple linear VAE
class LinearVAE(nn.Module):
    def __init__(self):
        super(LinearVAE, self).__init__()
 
        # encoder
        self.enc1 = nn.Linear(in_features=100, out_features=64)
        self.enc2 = nn.Linear(in_features=64, out_features=features*2)
 
        # decoder 
        self.dec1 = nn.Linear(in_features=features, out_features=64)
        self.dec2 = nn.Linear(in_features=64, out_features=100)
    def reparameterize(self, mu, log_var):
        """
        :param mu: mean from the encoder's latent space
        :param log_var: log variance from the encoder's latent space
        """
        std = torch.exp(0.5*log_var) # standard deviation
        eps = torch.randn_like(std) # `randn_like` as we need the same size
        sample = mu + (eps * std) # sampling as if coming from the input space
        return sample
 
    def forward(self, x):
        # encoding
        x = F.relu(self.enc1(x))
        x = self.enc2(x).view(-1, 2, features)
        # get `mu` and `log_var`
        mu = x[:, 0, :] # the first feature values as mean
        log_var = x[:, 1, :] # the other feature values as variance
        # get the latent vector through reparameterization
        z = self.reparameterize(mu, log_var)
 
        # decoding
        x = F.relu(self.dec1(z))
        reconstruction = torch.sigmoid(self.dec2(x))
   
        #reconstruction=torch.mul(reconstruction,mask)
        
        return reconstruction, mu, log_var
    
    def inference(self, mu, log_var):
        z = self.reparameterize(mu, log_var)
        
        x = F.relu(self.dec1(z))
        reconstruction = torch.sigmoid(self.dec2(x))
        return reconstruction
    
    def topn(self, reconstruction):
        value,indices=torch.topk(reconstruction,10)
        reconstruction[:]=0.0
        for i in range(indices.shape[0]):
           reconstruction[i,indices[i]]=1.0
        return reconstruction
