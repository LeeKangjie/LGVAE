
import torch
import model 
import torch.nn as nn
import torch.optim as optim
from utils import *
from tqdm import tqdm
import pickle
from torchvision.utils import save_image
import matplotlib

#torch.manual_seed(111)
torch.autograd.set_detect_anomaly(True)


device = ""
if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")


lr = 0.0001
batch_size = 10
epochs = 2000 #2000

train_number = 60
val_number = 72

#Preparing the training data
_, layouts=load_data('spacing+adjacency')#spacing spacing+adjacency is HLD-1 shape
layouts=layouts.to(device=device)
train_data=[(layouts[i]) for i in range(train_number)]
val_data=[(layouts[i]) for i in range(train_number,val_number)]


train_loader=torch.utils.data.DataLoader(train_data,batch_size=batch_size,shuffle=True)
val_loader=torch.utils.data.DataLoader(val_data,batch_size=batch_size,shuffle=True)

model = model.LinearVAE().to(device)
optimizer = optim.Adam(model.parameters(), lr=lr)
criterion = nn.BCELoss(reduction='sum')

def final_loss(bce_loss, mu, logvar):
    """
    This function will add the reconstruction loss (BCELoss) and the 
    KL-Divergence.
    KL-Divergence = 0.5 * sum(1 + log(sigma^2) - mu^2 - sigma^2)
    :param bce_loss: recontruction loss
    :param mu: the mean from the latent vector
    :param logvar: log variance from the latent vector
    """
    BCE = bce_loss 
    KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    return BCE + KLD

def fit(model, dataloader):
    model.train()
    running_loss = 0.0
    for i, data in tqdm(enumerate(dataloader), total=int(len(train_data)/dataloader.batch_size)):
        #data, _ = data
        data = data.to(device)
        data = data.view(data.size(0), -1)
        optimizer.zero_grad()
        reconstruction, mu, logvar = model(data)
        bce_loss = criterion(reconstruction, data)
        loss = final_loss(bce_loss, mu, logvar)
        running_loss += loss.item()
        loss.backward()
        optimizer.step()
    train_loss = running_loss/len(dataloader.dataset)

    file=open('save_mu.pickle','wb')
    pickle.dump(mu,file)
    file.close()
    file=open('save_log_var.pickle','wb')
    pickle.dump(logvar,file)
    file.close()
    return train_loss

def validate(model, dataloader):
    model.eval()
    running_loss = 0.0
    with torch.no_grad():
        for i, data in tqdm(enumerate(dataloader), total=int(len(val_data)/dataloader.batch_size)):
            #data, _ = data
            data = data.to(device)
            data = data.view(data.size(0), -1)#size batch_size*784
            reconstruction, mu, logvar = model(data)#size batch_size*(10*10)
            bce_loss = criterion(reconstruction, data)
            loss = final_loss(bce_loss, mu, logvar)
            running_loss += loss.item()
        
            # save the last batch input and output of every epoch
            reconstruction2=model.topn(reconstruction)
            if i == int(len(val_data)/dataloader.batch_size) - 1:
                num_rows = 8
                both = torch.cat((data.view(batch_size, 1, 10, 10)[:8], 
                                  reconstruction2.view(batch_size, 1, 10, 10)[:8]))
         
                save_image(both.cpu(), f"./outputs/output{epoch}.png", nrow=num_rows)
                file=open(f'./outputs/save_output{epoch}.pickle','wb')
               
                pickle.dump(both,file)
                file.close()
    val_loss = running_loss/len(dataloader.dataset)
    return val_loss


train_loss = []
val_loss = []
for epoch in range(epochs):
    print(f"Epoch {epoch+1} of {epochs}") #print("Epoch: {} Loss D.: {}".format(epoch,loss_discriminator))
    train_epoch_loss = fit(model, train_loader)
    val_epoch_loss = validate(model, val_loader)
    train_loss.append(train_epoch_loss)
    val_loss.append(val_epoch_loss)
    print(f"Train Loss: {train_epoch_loss:.4f}")
    print(f"Val Loss: {val_epoch_loss:.4f}")


File ="model.pth"
torch.save(model.state_dict(),File)


file=open('save_Loss_train_list.pickle','wb')
pickle.dump(train_loss,file)
file.close()
file=open('save_Loss_validation_list.pickle','wb')
pickle.dump(val_loss,file)
file.close()
