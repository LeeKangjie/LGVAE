import torch
from torch import nn
import torch.nn.functional as F

device = ""
if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")

class SelfAttention(nn.Module):
    def __init__(self, feature_dim):
        super(SelfAttention, self).__init__()
        self.query = nn.Linear(feature_dim, feature_dim)
        self.key = nn.Linear(feature_dim, feature_dim)
        self.value = nn.Linear(feature_dim, feature_dim)

    def forward(self, x):
        Q = self.query(x)
        K = self.key(x)
        V = self.value(x)
        attention_scores = F.softmax(Q @ K.transpose(-2, -1) / (K.shape[-1] ** 0.5), dim=-1)
        return attention_scores @ V



class ConditionalConvVAE(nn.Module):
    def __init__(self):
        super(ConditionalConvVAE, self).__init__()
        # Constants
        # Encoder
        self.enc_conv1 = nn.Conv2d(2, 16, kernel_size=3, stride=2, padding=1)  # Input channels = 2 for concatenated x and c
        self.enc_conv2 = nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=1)
        self.enc_att = SelfAttention(288)
        self.enc_fc = nn.Linear(288, 16 * 2)
        # Decoder
        self.dec_fc1 = nn.Linear(16 + 100, 288)  
        self.dec_att = SelfAttention(288)
        self.dec_conv1 = nn.ConvTranspose2d(32, 16, kernel_size=3, stride=1, padding=0)
        self.dec_conv2 = nn.ConvTranspose2d(16, 1, kernel_size=4, stride=2, padding=1, output_padding=0)  # Corrected to get (10, 10) output


    def reparameterize(self, mu, log_var):
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x, c):
        bs = x.size(0)
        # Ensure x and c are seen as single-channel images
        x = x.view(bs, 1, 10, 10)
        c = c.view(bs, 1, 10, 10)
        # Concatenate x and c for the input
        x = torch.cat([x, c], dim=1)  # Concatenate along the channel dimension(bs,2,10,10)
        # Encoder
        x = F.relu(self.enc_conv1(x))#(bs,16,5,5)
        x = F.relu(self.enc_conv2(x))#(bs,32,3,3)
        x = x.view(bs, -1)#(bs,288)
        x = F.relu(self.enc_att(x))#(bs,288)
        x = self.enc_fc(x).view(-1, 2, 16)#(bs,2,16)
        mu = x[:, 0, :]
        log_var = x[:, 1, :]
        z = self.reparameterize(mu, log_var)#(bs,16)
        # Prepare for decoding
        c_flat = c.view(bs, -1)  # Flatten c#(bs,100)
        z = torch.cat([z, c_flat], dim=1)  # Concatenate z and flattened c#(bs,116)
        # Decoder
        z = F.relu(self.dec_fc1(z))#(bs,288)
        z = F.relu(self.dec_att(z))#(bs,288)
        z = z.view(bs, 32, 3, 3)  # Adjust shape appropriately
        x = F.relu(self.dec_conv1(z))#(bs,16,5,5)
        x = torch.sigmoid(self.dec_conv2(x))#(bs,1,10,10)
        return x.squeeze(), mu, log_var

    def inference(self, c):
        bs = c.size(0)
        z = torch.randn(bs, 16).to(c.device)
        c_flat = c.view(bs, -1)
        z = torch.cat([z, c_flat], dim=1)#(bs,106)
        #Decoder
        z = F.relu(self.dec_fc1(z))
        z = F.relu(self.dec_att(z))
        z = z.view(bs, 32, 3, 3)  # Adjust the shape to match decoder layers
        x = F.relu(self.dec_conv1(z))
        x = torch.sigmoid(self.dec_conv2(x))
        return x.squeeze()
    
    def topn(self, reconstruction):
        # Assuming reconstruction shape is (batch_size, 10, 10)
        batch_size = reconstruction.shape[0]
        flattened_reconstruction = reconstruction.view(batch_size, -1)
        mask = torch.zeros_like(flattened_reconstruction)
        for i in range(batch_size):
            _, indices = torch.topk(flattened_reconstruction[i], 10)
            mask[i, indices] = 1.0
        mask = mask.view(batch_size, 10, 10)
        return mask


'''
class ConditionalConvVAE(nn.Module):
    def __init__(self):
        super(ConditionalConvVAE, self).__init__()
        # Encoder
        self.enc_conv1 = nn.Conv2d(2, 16, kernel_size=3, stride=2, padding=1)
        self.enc_conv2 = nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=1)
        self.enc_lin1 = nn.Linear(288, 144)  # First linear layer
        self.enc_lin2 = nn.Linear(144, 288)  # Second linear layer to restore dimension
        self.enc_fc = nn.Linear(288, 16 * 2)  # Latent space size is 16

        # Decoder
        self.dec_fc1 = nn.Linear(16 + 100, 132)  
        self.dec_lin1 = nn.Linear(132, 144)  # First linear layer
        self.dec_lin2 = nn.Linear(144, 288)  # Second linear layer to restore dimension
        self.dec_conv1 = nn.ConvTranspose2d(32, 16, kernel_size=3, stride=1, padding=0)
        self.dec_conv2 = nn.ConvTranspose2d(16, 1, kernel_size=4, stride=2, padding=1, output_padding=0)  # To get (10, 10) output

    def reparameterize(self, mu, log_var):
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x, c):
        bs = x.size(0)
        # Ensure x and c are seen as single-channel images
        x = x.view(bs, 1, 10, 10)
        c = c.view(bs, 1, 10, 10)
        # Concatenate x and c for the input
        x = torch.cat([x, c], dim=1)#(10,2,10,10)
        # Encoder
        x = F.relu(self.enc_conv1(x))#(10,16,5,5)
        x = F.relu(self.enc_conv2(x))#(10,32,3,3)
        x = x.view(bs, -1)
        x = F.relu(self.enc_lin1(x))#(10,144)
        x = F.relu(self.enc_lin2(x))#(10,288)
        x = self.enc_fc(x).view(-1, 2, 16)
        mu = x[:, 0, :]
        log_var = x[:, 1, :]
        z = self.reparameterize(mu, log_var)
        # Prepare for decoding
        c_Zflat = c.view(bs, -1)
        z = torch.cat([z, c_flat], dim=1)#(10,116)
        # Decoder
        z = F.relu(self.dec_fc1(z))#(10,132)
        z = F.relu(self.dec_lin1(z))#(10,144)
        z = F.relu(self.dec_lin2(z))#(10,288)
        z = z.view(bs, 32, 3, 3)#(10,32,3,3)
        x = F.relu(self.dec_conv1(z))#(10,16,5,5)
        x = torch.sigmoid(self.dec_conv2(x))#(10,1,10,10)
        return x.squeeze(), mu, log_var

    def inference(self, c):
        bs = c.size(0)
        z = torch.randn(bs, 16).to(c.device)
        c_flat = c.view(bs, -1)
        z = torch.cat([z, c_flat], dim=1)#(bs,106)
        # Decoder
        z = F.relu(self.dec_fc1(z))
        z = F.relu(self.dec_lin1(z))
        z = F.relu(self.dec_lin2(z))
        z = z.view(bs, 32, 3, 3)
        x = F.relu(self.dec_conv1(z))
        x = torch.sigmoid(self.dec_conv2(x))
        return x.squeeze()
    
    def topn(self, reconstruction):
        # Assuming reconstruction shape is (batch_size, 10, 10)
        batch_size = reconstruction.shape[0]
        flattened_reconstruction = reconstruction.view(batch_size, -1)
        mask = torch.zeros_like(flattened_reconstruction)
        for i in range(batch_size):
            _, indices = torch.topk(flattened_reconstruction[i], 10)
            mask[i, indices] = 1.0
        mask = mask.view(batch_size, 10, 10)
        return mask
'''