
import torch
import model 
import model_attention
import torch.nn as nn
import torch.optim as optim
from utils import *
from tqdm import tqdm
import pickle
from torchvision.utils import save_image
import matplotlib
import torch.nn.functional as F
import random

#torch.manual_seed(111)
torch.autograd.set_detect_anomaly(True)


device = ""
if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")


lr = 0.0001*0.5#0.0001*0.6#0.0001*0.6#0.0001
batch_size = 10#10*6#10
epochs = 4000#2000#2000 

train_number =60#60*5 #100 #60   #70
val_number = 72#72*5 #128   #72  #88

#Preparing the training data
cond, layouts=load_data('spacing+adjacency')#'spacing' spacing+adjacency

cond, layouts=data_2_array(cond, layouts)#shape: 72*10*10
cond=cond.to(device=device)
layouts=layouts.to(device=device)
'''
# train_data=[(layouts[i],cond[i]) for i in range(train_number)]
# val_data=[(layouts[i],cond[i]) for i in range(train_number,val_number)]

layout2 = augment_layout(layouts)
layout3 = augment_layout(layouts)
layout4 = augment_layout(layouts)
layout5 = augment_layout(layouts)
augmented_layouts = torch.cat((layouts, layout2, layout3, layout4, layout5), dim=0)
augmented_cond = torch.cat([cond]*5, dim=0)
total_data = list(zip(augmented_layouts, augmented_cond))
'''

total_data = list(zip(layouts, cond))
random.shuffle(total_data)
train_data = total_data[:train_number]
val_data = total_data[train_number:val_number]

train_loader=torch.utils.data.DataLoader(train_data,batch_size=batch_size,shuffle=True)
val_loader=torch.utils.data.DataLoader(val_data,batch_size=batch_size,shuffle=True)

#model = model.LinearVAE().to(device)
model = model_attention.ConditionalConvVAE().to(device)
optimizer = optim.Adam(model.parameters(), lr=lr)
#scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=100, gamma=0.5)
criterion = nn.BCELoss(reduction='sum')
def cons_loss(reconstruction):
    K=[[0,0,0.1,0,0],[0,0,0.5,0,0],[0.1,0.5,1.0,0.5,0.1],[0,0,0.5,0,0],[0,0,0.1,0,0]]
    kernel=torch.FloatTensor(K).unsqueeze(0).unsqueeze(0).to(device=device)   
    a=reconstruction.shape[0]
    for i in range(a):
        generated_layout2=torch.reshape(reconstruction[i],(1,1,10,10))
        Penalty_field=F.conv2d(generated_layout2,kernel,padding=(2,2)) 
        ze=torch.zeros(10,10).unsqueeze(0).unsqueeze(0).to(device=device)
        Penalty_field=torch.where(Penalty_field>1.45,Penalty_field,ze)
        Penalty_field=torch.reshape(Penalty_field,(1,100))
        loss = torch.sum(Penalty_field)   
    return 0.1*loss

def final_loss(bce_loss, mu, logvar):
    """
    This function will add the reconstruction loss (BCELoss) and the 
    KL-Divergence.
    KL-Divergence = 0.5 * sum(1 + log(sigma^2) - mu^2 - sigma^2)
    :param bce_loss: recontruction loss
    :param mu: the mean from the latent vector
    :param logvar: log variance from the latent vector
    """
    BCE = bce_loss 
    KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    return BCE + KLD

def fit(model, dataloader):
    model.train()
    running_loss = 0.0
    for i, data in tqdm(enumerate(dataloader), total=int(len(train_data)/dataloader.batch_size)):
        data, cond = data
        cond = cond.to(device)
        data = data.to(device)
        #data = data.view(data.size(0), -1)
        optimizer.zero_grad()
        reconstruction, mu, logvar = model(data, cond)
        bce_loss = criterion(reconstruction, data)
        loss = final_loss(bce_loss, mu, logvar)

        #c_loss=cons_loss(reconstruction)
        #loss=loss+c_loss
        
        running_loss += loss.item()
        loss.backward()
        optimizer.step()
    train_loss = running_loss/len(dataloader.dataset)

    file=open('save_mu.pickle','wb')
    pickle.dump(mu,file)
    file.close()
    file=open('save_log_var.pickle','wb')
    pickle.dump(logvar,file)
    file.close()
    return train_loss

def validate(model, dataloader):
    model.eval()
    running_loss = 0.0
    with torch.no_grad():
        for i, data in tqdm(enumerate(dataloader), total=int(len(val_data)/dataloader.batch_size)):
            data, cond = data
            data = data.to(device)
            cond = cond.to(device)
            #data = data.view(data.size(0), -1)#size batch_size*784
            reconstruction, mu, logvar = model(data, cond)#size batch_size*(10*10)
            bce_loss = criterion(reconstruction, data)
            loss = final_loss(bce_loss, mu, logvar)
            running_loss += loss.item()
        
            # save the last batch input and output of every epoch
            # reconstruction2=model.topn(reconstruction)
            # if i == int(len(val_data)/dataloader.batch_size) - 1:
            #     num_rows = 8
            #     both = torch.cat((data.view(batch_size, 1, 10, 10)[:8], 
            #                       reconstruction2.view(batch_size, 1, 10, 10)[:8]))
            #     
            #     save_image(both.cpu(), "./outputs/output{}.png".format(epoch), nrow=num_rows)
            #     file=open('./outputs/save_output{}.pickle'.format(epoch),'wb')
            #     
            #     pickle.dump(both,file)
            #     file.close()
    val_loss = running_loss/len(dataloader.dataset)
    return val_loss


train_loss = []
val_loss = []
for epoch in range(epochs):
    print("Epoch {} of {}".format(epoch+1,epochs)) #print("Epoch: {} Loss D.: {}".format(epoch,loss_discriminator))
    train_epoch_loss = fit(model, train_loader)
    val_epoch_loss = validate(model, val_loader)
    train_loss.append(train_epoch_loss)
    val_loss.append(val_epoch_loss)
    print("Train Loss: {}".format(train_epoch_loss))
    print("Val Loss: {}".format(val_epoch_loss))
    #scheduler.step()


File ="model.pth"
torch.save(model.state_dict(),File)


file=open('save_Loss_train_list.pickle','wb')
pickle.dump(train_loss,file)
file.close()
file=open('save_Loss_validation_list.pickle','wb')
pickle.dump(val_loss,file)
file.close()
