import numpy as np
import scipy.sparse as sp
import scipy.io as sio
import torch
from torch.nn.functional import normalize
import matplotlib.pyplot as plt


device = ""
if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")


def load_data(dataset_str,path="./data/"): 
    path = path + dataset_str +"/"

    if dataset_str == "spacing":
        features = sio.loadmat(path + "feature")
        features = features['matrix']
        layouts = sio.loadmat(path + "layout")
        layouts = layouts['matrix']
        features = torch.FloatTensor(np.array(features.todense()))
        layouts = torch.FloatTensor(np.array(layouts.todense()))

    elif dataset_str == "spacing+adjacency":
        features = sio.loadmat(path + "feature")
        features = features['matrix']
        layouts = sio.loadmat(path + "layout")
        layouts = layouts['matrix']

        features = torch.FloatTensor(np.array(features.todense()))
        layouts = torch.FloatTensor(np.array(layouts.todense()))
        

    else:
        features = sio.loadmat(path + "feature")
        features = features['matrix']
        layouts = sio.loadmat(path + "layout")
        layouts = layouts['matrix']

        features = torch.FloatTensor(np.array(features.todense()))
        layouts = torch.FloatTensor(np.array(layouts.todense()))
        

    return features, layouts

def augment_layout(layouts, flip_prob=0.02):
    device = layouts.device
    flip_mask = torch.rand(layouts.shape, device=device) < flip_prob
    augmented_layouts = torch.where(flip_mask, 1 - layouts, layouts)
    return augmented_layouts

def data_2_array(features,layouts):
    feature_array=torch.zeros(len(features),10,10)
    layout_array=torch.zeros(len(features),10,10)
    for i in range(len(features)):
        featurei=torch.zeros(10,10)
        featurei[features[i,0].long(),features[i,1].long()]=1
        feature_array[i]=featurei
        layout_array[i]=torch.reshape(layouts[i],(10,10))
        #R=featurei
        #R=layout_array[i]
        #plt.imshow(R,cmap='bone')
    return feature_array, layout_array